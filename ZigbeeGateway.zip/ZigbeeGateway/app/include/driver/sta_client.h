#ifndef STP_CLIENT_APP_H
#define STP_CLIENT_APP_H

#define		TCP_SERVER_IP		"192.168.0.104"			//ip地址

typedef void (*tcp_exp_callback)(void *, sint8);
typedef void (*connect_success_callback)(void *);
typedef void (*disconect_callback)(void *);
typedef void (*recieve_data_callback)(void *, char *, unsigned short);
typedef void (*send_success_callback)(void *);


typedef struct _tcp_client_config {
	tcp_exp_callback exp_callback;
	connect_success_callback con_success_callback;
	disconect_callback disconn_callback;
	recieve_data_callback rev_data_callback;
	send_success_callback send_success_callback;
}tcp_client_config;

void STA_TCP_Client_Init(tcp_client_config*);		// ESP8266_STA鍒濆鍖�

#endif
