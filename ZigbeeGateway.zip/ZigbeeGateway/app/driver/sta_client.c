#include "user_interface.h"
#include "user_config.h"
#include "c_types.h"
#include "ip_addr.h"
#include "espconn.h"
#include "ets_sys.h"

#include "mem.h"
#include "os_type.h"
#include "osapi.h"
#include "driver/sta_client.h"

#include "smartconfig.h"		// 智能配网

#define		Sector_STA_INFO		0x80			// 【STA参数】保存扇区

static tcp_client_config* client_config;

//建立过程使用查询法判断TCP连接状态 ，因此需要使用定时器 1
static os_timer_t OS_Timer_1;

//基本的配置
static struct espconn ST_NetCon;

void ICACHE_FLASH_ATTR ESP8266_TCP_Connect_Cb(void *arg);
void ICACHE_FLASH_ATTR OS_Timer_1_Init_JX(u32 time_ms,u8 time_repetitive);
void ICACHE_FLASH_ATTR ESP8266_TCP_Break_Cb(void *arg, sint8 err);

static struct station_config STA_Config;

void STA_TCP_Client_Init(tcp_client_config* config)
{
	client_config = config;
	struct ip_info ST_ESP8266_IP;

	os_memset(&STA_Config,0,sizeof(struct station_config));			// STA_INFO = 0

	spi_flash_read(Sector_STA_INFO*4096,(uint32 *)&STA_Config, 96);	// 读出【STA参数】(SSID/PASS)
	STA_Config.ssid[31] = 0;		// SSID最后添'\0'
	STA_Config.password[63] = 0;	// APSS最后添'\0'
	os_printf("\r\nSTA_INFO.ssid=%s\r\nSTA_INFO.password=%s\r\n",STA_Config.ssid,STA_Config.password);

	wifi_set_opmode(0x01); //设置成为STA模式
	wifi_station_set_config(&STA_Config);
	OS_Timer_1_Init_JX(1000, 1);		// 1秒定时
}

// 初始化网络连接(TCP通信)
//=========================================================================================================
void ICACHE_FLASH_ATTR ESP8266_NetCon_Init_JX()
{
	// 结构体赋值
	//--------------------------------------------------------------------------
	ST_NetCon.type = ESPCONN_TCP;				// 设置为TCP协议
	ST_NetCon.proto.tcp = (esp_tcp *) os_zalloc(sizeof(esp_tcp));	// 开辟内存
	//TODO 这儿需要从配置中解析出IP地址
	//-------------------------------------------------------------------------
	ST_NetCon.proto.tcp->local_port = 8266;	// 设置本地端口
	ST_NetCon.proto.tcp->remote_port = 8888;	// 设置目标端口
	ST_NetCon.proto.tcp->remote_ip[0] = 192;	// 设置目标IP地址
	ST_NetCon.proto.tcp->remote_ip[1] = 168;
	ST_NetCon.proto.tcp->remote_ip[2] = 1;
	ST_NetCon.proto.tcp->remote_ip[3] = 8;

	// 注册连接成功回调函数、异常断开回调函数
	//--------------------------------------------------------------------------------------------------
	espconn_regist_connectcb(&ST_NetCon, ESP8266_TCP_Connect_Cb);// 注册TCP连接成功建立的回调函数
	espconn_regist_reconcb(&ST_NetCon, ESP8266_TCP_Break_Cb);// 注册TCP连接异常断开的回调函数
	// 连接 TCP server
	//----------------------------------------------------------
	espconn_connect(&ST_NetCon);	// 连接TCP-server
}

void connect_server()
{
	struct ip_info ST_ESP8266_IP;	// ESP8266的IP信息
	u8 ESP8266_IP[4];				// ESP8266的IP地址
	wifi_get_ip_info(STATION_IF, &ST_ESP8266_IP);	// 获取STA的IP信息
	ESP8266_IP[0] = ST_ESP8266_IP.ip.addr;			// IP地址高八位 == addr低八位
	ESP8266_IP[1] = ST_ESP8266_IP.ip.addr >> 8;		// IP地址次高八位 == addr次低八位
	ESP8266_IP[2] = ST_ESP8266_IP.ip.addr >> 16;	// IP地址次低八位 == addr次高八位
	ESP8266_IP[3] = ST_ESP8266_IP.ip.addr >> 24;	// IP地址低八位 == addr高八位

	// 显示ESP8266的IP地址
	//-----------------------------------------------------------------------------------------------
	os_printf("ESP8266_IP = %d.%d.%d.%d\n", ESP8266_IP[0], ESP8266_IP[1],
			ESP8266_IP[2], ESP8266_IP[3]);
	//-----------------------------------------------------------------------------------------------
	os_timer_disarm(&OS_Timer_1);	// 关闭定时器
	ESP8266_NetCon_Init_JX();		// 初始化网络连接(TCP通信)
}

// SmartConfig状态发生改变时，进入此回调函数
//--------------------------------------------
// 参数1：sc_status status / 参数2：无类型指针【在不同状态下，[void *pdata]的传入参数是不同的】
//=================================================================================================================
void ICACHE_FLASH_ATTR smartconfig_done(sc_status status, void *pdata)
{
	os_printf("\r\n------ smartconfig_done ------\r\n");	// ESP8266网络状态改变
	u8 ESP8266_IP[4];				// ESP8266的IP地址
	struct ip_info ST_ESP8266_IP;
	switch(status)
	{
		// CmartConfig等待
		//……………………………………………………
		case SC_STATUS_WAIT:		// 初始值
			os_printf("\r\nSC_STATUS_WAIT\r\n");
		break;
		//……………………………………………………
		// 发现【WIFI信号】（8266在这种状态下等待配网）
		//…………………………………………………………………………………………………
		case SC_STATUS_FIND_CHANNEL:
			os_printf("\r\nSC_STATUS_FIND_CHANNEL\r\n");
			os_printf("\r\n---- Please Use WeChat to SmartConfig ------\r\n\r\n");
		break;
		//…………………………………………………………………………………………………

		// 正在获取【SSID】【PSWD】（8266正在抓取并解密【SSID+PSWD】）
		//…………………………………………………………………………………………………
		case SC_STATUS_GETTING_SSID_PSWD:
			os_printf("\r\nSC_STATUS_GETTING_SSID_PSWD\r\n");

			// 【SC_STATUS_GETTING_SSID_PSWD】状态下，参数2==SmartConfig类型指针
			//-------------------------------------------------------------------
			sc_type *type = pdata;		// 获取【SmartConfig类型】指针
			// 配网方式 == 【ESPTOUCH】
			//-------------------------------------------------
			if (*type == SC_TYPE_ESPTOUCH)
			{ os_printf("\r\nSC_TYPE:SC_TYPE_ESPTOUCH\r\n"); }

			// 配网方式 == 【AIRKISS】||【ESPTOUCH_AIRKISS】
			//-------------------------------------------------
			else
			{ os_printf("\r\nSC_TYPE:SC_TYPE_AIRKISS\r\n"); }

		break;
		//…………………………………………………………………………………………………

		// 成功获取到【SSID】【PSWD】，保存STA参数，并连接WIFI
		//…………………………………………………………………………………………………
		case SC_STATUS_LINK:
			os_printf("\r\nSC_STATUS_LINK\r\n");

			// 【SC_STATUS_LINK】状态下，参数2 == STA参数结构体指针
			//------------------------------------------------------------------
			struct station_config *sta_conf = pdata;	// 获取【STA参数】指针

			// 将【SSID】【PASS】保存到【外部Flash】中
			//--------------------------------------------------------------------------
			spi_flash_erase_sector(Sector_STA_INFO);						// 擦除扇区
			spi_flash_write(Sector_STA_INFO*4096, (uint32 *)sta_conf, 96);	// 写入扇区
			//--------------------------------------------------------------------------

			wifi_station_set_config(sta_conf);			// 设置STA参数【Flash】
			wifi_station_disconnect();					// 断开STA连接
			wifi_station_connect();						// ESP8266连接WIFI

		break;
		//…………………………………………………………………………………………………

		// ESP8266作为STA，成功连接到WIFI
		//…………………………………………………………………………………………………
		case SC_STATUS_LINK_OVER:
			os_printf("\r\nSC_STATUS_LINK_OVER\r\n");

			smartconfig_stop();		// 停止SmartConfig，释放内存

			//**************************************************************************************************
			wifi_get_ip_info(STATION_IF,&ST_ESP8266_IP);	// 获取8266_STA的IP地址

			ESP8266_IP[0] = ST_ESP8266_IP.ip.addr;		// IP地址高八位 == addr低八位
			ESP8266_IP[1] = ST_ESP8266_IP.ip.addr>>8;	// IP地址次高八位 == addr次低八位
			ESP8266_IP[2] = ST_ESP8266_IP.ip.addr>>16;	// IP地址次低八位 == addr次高八位
			ESP8266_IP[3] = ST_ESP8266_IP.ip.addr>>24;	// IP地址低八位 == addr高八位

			// 显示ESP8266的IP地址
			//-----------------------------------------------------------------------------------------------
			os_printf("ESP8266_IP = %d.%d.%d.%d\n",ESP8266_IP[0],ESP8266_IP[1],ESP8266_IP[2],ESP8266_IP[3]);
			os_printf("\r\n---- ESP8266 Connect to WIFI Successfully ----\r\n");
			// 开始进行TCP连接  Server
			connect_server();

		break;

	}
}


// 软件定时的回调函数
//=========================================================================================================
static void ICACHE_FLASH_ATTR OS_Timer_1_cb(void)
{

	u8 S_WIFI_STA_Connect;			// WIFI接入状态标志

	os_printf("ESP8266_IP Detect!!!!!!!!!\n");
	S_WIFI_STA_Connect =wifi_station_get_connect_status();
	// 成功接入WIFI【STA模式下，如果开启DHCP(默认)，则ESO8266的IP地址由WIFI路由器自动分配】
	//-------------------------------------------------------------------------------------
	//TODO 将接入WiFi成功后的代码抽象出来一个代码块
	if (S_WIFI_STA_Connect == STATION_GOT_IP)	// 判断是否获取IP
	{
		connect_server();

	}else if(S_WIFI_STA_Connect==STATION_NO_AP_FOUND 	||		// 未找到指定WIFI
			S_WIFI_STA_Connect==STATION_WRONG_PASSWORD 	||		// WIFI密码错误
			S_WIFI_STA_Connect==STATION_CONNECT_FAIL		)	// 连接WIFI失败
	{
		//开始进行，智能配网
		os_timer_disarm(&OS_Timer_1);			// 关闭定时器

		os_printf("\r\n---- S_WIFI_STA_Connect=%d-----------\r\n",S_WIFI_STA_Connect);
		os_printf("\r\n---- ESP8266 Can't Connect to WIFI-----------\r\n");

		// 微信智能配网设置

		smartconfig_set_type(SC_TYPE_AIRKISS); 	// ESP8266配网方式【AIRKISS】			//【第②步】

		smartconfig_start(smartconfig_done);	// 进入【智能配网模式】,并设置回调函数	//【第③步】
		//…………………………………………………………………………………………………………………………
	}

}

void ICACHE_FLASH_ATTR OS_Timer_1_Init_JX(u32 time_ms,
		u8 time_repetitive)
{
	os_timer_disarm(&OS_Timer_1);	// 关闭定时器
	os_timer_setfn(&OS_Timer_1, (os_timer_func_t *) OS_Timer_1_cb, NULL);// 设置定时器
	os_timer_arm(&OS_Timer_1, time_ms, time_repetitive);  // 使能定时器
}


/*
 * 数据发送成功
 * */
static void ICACHE_FLASH_ATTR ESP8266_WIFI_Send_Cb(void *arg)
{
	if (client_config && client_config->send_success_callback)
		client_config->send_success_callback(arg);
}

// 成功接收网络数据的回调函数【参数1：网络传输结构体espconn指针、参数2：网络传输数据指针、参数3：数据长度】
//=========================================================================================================
static void ICACHE_FLASH_ATTR ESP8266_WIFI_Recv_Cb(void * arg, char * pdata,
		unsigned short len)
{
	if (client_config && client_config->rev_data_callback)
		client_config->rev_data_callback(arg, pdata, len);
}

// TCP连接断开成功的回调函数
//================================================================
static void ICACHE_FLASH_ATTR ESP8266_TCP_Disconnect_Cb(void *arg)
{
	if (client_config && client_config->disconn_callback)
		client_config->disconn_callback(arg);
}

//TCP 连接建立成功的回调函数
//====================================================================================================================
void ICACHE_FLASH_ATTR ESP8266_TCP_Connect_Cb(void *arg)
{
	espconn_regist_sentcb((struct espconn *)arg, ESP8266_WIFI_Send_Cb);			// 注册网络数据发送成功的回调函数
	espconn_regist_recvcb((struct espconn *)arg, ESP8266_WIFI_Recv_Cb);			// 注册网络数据接收成功的回调函数
	espconn_regist_disconcb((struct espconn *)arg,ESP8266_TCP_Disconnect_Cb);	// 注册成功断开TCP连接的回调函数

	if (client_config && client_config->con_success_callback)
		client_config->con_success_callback(arg);
}

// TCP连接异常断开时的回调函数【ESP8266作为TCP_Client，连接TCP_Server失败，也会进入此函数】
//==========================================================================================
void ICACHE_FLASH_ATTR ESP8266_TCP_Break_Cb(void *arg, sint8 err)
{
	os_printf("\nESP8266_TCP_Break\n");
//	espconn_connect(&ST_NetCon);	// 连接TCP-server
	espconn_connect(&ST_NetCon);
	if (client_config && client_config->exp_callback)
		client_config->exp_callback(arg, err);
}

